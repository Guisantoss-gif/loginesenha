
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;

public class SistemaUnico {

    // Configurações do banco de dados
    private static final String URL_BANCO =
            "jdbc:mysql://localhost:3306/db_sistema?useSSL=false&serverTimezone=UTC";
    private static final String USUARIO_BANCO = "root";
    private static final String SENHA_BANCO = "";

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SistemaUnico::mostrarAcesso);
    }

    // Conexão com o MySQL
    private static Connection conectar() throws SQLException {
        return DriverManager.getConnection(
                URL_BANCO, USUARIO_BANCO, SENHA_BANCO);
    }

    // PRIMEIRA TELA: LOGIN
    private static void mostrarAcesso() {

        JFrame janela = new JFrame("Acesso ao Sistema");
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setSize(410, 245);
        janela.setLocationRelativeTo(null);

        JPanel principal = new JPanel(new BorderLayout(12, 12));
        principal.setBorder(
                BorderFactory.createEmptyBorder(18, 20, 15, 20));

        JLabel titulo = new JLabel(
                "Entre para continuar", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));

        principal.add(titulo, BorderLayout.NORTH);

        JPanel campos = new JPanel(new GridLayout(2, 2, 8, 12));

        JTextField campoLogin = new JTextField(18);
        JPasswordField campoSenha = new JPasswordField(18);

        campos.add(new JLabel("Login:"));
        campos.add(campoLogin);
        campos.add(new JLabel("Senha:"));
        campos.add(campoSenha);

        principal.add(campos, BorderLayout.CENTER);

        JButton entrar = new JButton("Entrar");
        JButton criarConta = new JButton("Criar conta");

        JPanel botoes = new JPanel();
        botoes.add(entrar);
        botoes.add(criarConta);

        principal.add(botoes, BorderLayout.SOUTH);

        // BOTÃO ENTRAR
        entrar.addActionListener(e -> {

            String login = campoLogin.getText().trim();
            String senha = new String(campoSenha.getPassword());

            if (login.isEmpty() || senha.isEmpty()) {
                JOptionPane.showMessageDialog(
                        janela, "Informe o login e a senha.");
                return;
            }

            try {
                if (validarAcesso(login, senha)) {

                    janela.dispose();
                    mostrarCadastro();

                } else {
                    JOptionPane.showMessageDialog(
                            janela,
                            "Login ou senha incorretos.",
                            "Acesso negado",
                            JOptionPane.WARNING_MESSAGE);
                }

            } catch (SQLException ex) {
                mostrarErroBanco(janela, ex);
            }
        });

        // BOTÃO CRIAR CONTA
        criarConta.addActionListener(e -> {

            String login = campoLogin.getText().trim();
            String senha = new String(campoSenha.getPassword());

            if (login.isEmpty() || senha.isEmpty()) {
                JOptionPane.showMessageDialog(
                        janela,
                        "Digite um login e uma senha antes de criar a conta.");
                return;
            }

            if (senha.length() < 4) {
                JOptionPane.showMessageDialog(
                        janela,
                        "A senha precisa ter pelo menos 4 caracteres.");
                return;
            }

            try {

                criarConta(login, senha);

                JOptionPane.showMessageDialog(
                        janela,
                        "Conta criada! Agora entre com seu login e senha.");

                campoSenha.setText("");
                campoSenha.requestFocus();

            } catch (SQLIntegrityConstraintViolationException ex) {

                JOptionPane.showMessageDialog(
                        janela,
                        "Esse login já está cadastrado. Escolha outro.");

            } catch (SQLException ex) {
                mostrarErroBanco(janela, ex);
            }
        });

        janela.setContentPane(principal);
        janela.setVisible(true);
    }

    // VERIFICA LOGIN E SENHA
    private static boolean validarAcesso(
            String login, String senha) throws SQLException {

        String comando =
                "SELECT id FROM autenticacao WHERE login = ? AND senha = ?";

        try (Connection conexao = conectar();
             PreparedStatement consulta =
                     conexao.prepareStatement(comando)) {

            consulta.setString(1, login);
            consulta.setString(2, gerarHash(senha));

            try (ResultSet resultado = consulta.executeQuery()) {
                return resultado.next();
            }
        }
    }

    // CADASTRA NOVA CONTA
    private static void criarConta(
            String login, String senha) throws SQLException {

        String comando =
                "INSERT INTO autenticacao (login, senha) VALUES (?, ?)";

        try (Connection conexao = conectar();
             PreparedStatement insercao =
                     conexao.prepareStatement(comando)) {

            insercao.setString(1, login);
            insercao.setString(2, gerarHash(senha));

            insercao.executeUpdate();
        }
    }

    // GERA HASH SHA-256 PARA A SENHA
    private static String gerarHash(String senha) {

        try {

            MessageDigest sha =
                    MessageDigest.getInstance("SHA-256");

            byte[] bytes = sha.digest(
                    senha.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexadecimal = new StringBuilder();

            for (byte b : bytes) {
                hexadecimal.append(
                        String.format("%02x", b));
            }

            return hexadecimal.toString();

        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException(
                    "Não foi possível proteger a senha.", ex);
        }
    }

    // SEGUNDA TELA: CADASTRO DE NOMES
    private static void mostrarCadastro() {

        JFrame janela = new JFrame("Cadastro de Usuários");
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setSize(520, 410);
        janela.setLocationRelativeTo(null);
        janela.setLayout(new BorderLayout(12, 12));

        JPanel topo = new JPanel(
                new FlowLayout(FlowLayout.CENTER, 8, 12));

        JTextField campoNome = new JTextField(19);
        JButton adicionar = new JButton("Adicionar nome");

        topo.add(new JLabel("Nome:"));
        topo.add(campoNome);
        topo.add(adicionar);

        DefaultTableModel tabelaModelo =
                new DefaultTableModel(
                        new Object[]{"Código", "Nome cadastrado"}, 0) {

                    @Override
                    public boolean isCellEditable(
                            int linha, int coluna) {
                        return false;
                    }
                };

        JTable tabela = new JTable(tabelaModelo);
        tabela.setRowHeight(24);

        JScrollPane rolagem = new JScrollPane(tabela);

        JButton sair = new JButton("Sair da conta");

        JPanel rodape = new JPanel(
                new FlowLayout(FlowLayout.RIGHT));

        rodape.add(sair);

        janela.add(topo, BorderLayout.NORTH);
        janela.add(rolagem, BorderLayout.CENTER);
        janela.add(rodape, BorderLayout.SOUTH);

        // CARREGA OS NOMES DO BANCO
        try {
            atualizarTabela(tabelaModelo);

        } catch (SQLException ex) {
            mostrarErroBanco(janela, ex);
        }

        // ADICIONAR NOME
        adicionar.addActionListener(e -> {

            String nome = campoNome.getText().trim();

            if (nome.isEmpty()) {
                JOptionPane.showMessageDialog(
                        janela,
                        "Digite o nome que deseja cadastrar.");
                return;
            }

            try {

                salvarNome(nome);

                campoNome.setText("");
                atualizarTabela(tabelaModelo);
                campoNome.requestFocus();

                JOptionPane.showMessageDialog(
                        janela,
                        "Nome cadastrado com sucesso!");

            } catch (SQLException ex) {
                mostrarErroBanco(janela, ex);
            }
        });

        // SAIR DA CONTA
        sair.addActionListener(e -> {

            janela.dispose();
            mostrarAcesso();
        });

        janela.setVisible(true);
    }

    // SALVA NOME NO MYSQL
    private static void salvarNome(String nome)
            throws SQLException {

        String comando =
                "INSERT INTO usuarios (nome) VALUES (?)";

        try (Connection conexao = conectar();
             PreparedStatement insercao =
                     conexao.prepareStatement(comando)) {

            insercao.setString(1, nome);
            insercao.executeUpdate();
        }
    }

    // ATUALIZA A TABELA DA INTERFACE
    private static void atualizarTabela(
            DefaultTableModel modelo) throws SQLException {

        modelo.setRowCount(0);

        String comando =
                "SELECT id, nome FROM usuarios ORDER BY id";

        try (Connection conexao = conectar();
             PreparedStatement consulta =
                     conexao.prepareStatement(comando);
             ResultSet resultado = consulta.executeQuery()) {

            while (resultado.next()) {

                modelo.addRow(new Object[]{
                        resultado.getInt("id"),
                        resultado.getString("nome")
                });
            }
        }
    }

    // EXIBE ERROS DE CONEXÃO
    private static void mostrarErroBanco(
            Component pai, SQLException ex) {

        ex.printStackTrace();

        JOptionPane.showMessageDialog(
                pai,
                "Não foi possível acessar o banco de dados.\n"
                + "Confira se o MySQL está ligado e se usuário/senha estão corretos.\n\n"
                + ex.getMessage(),
                "Erro de banco de dados",
                JOptionPane.ERROR_MESSAGE);
    }
}
