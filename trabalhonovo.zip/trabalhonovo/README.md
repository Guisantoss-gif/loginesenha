
# Sistema de Cadastro de Usuários

Aplicação desktop desenvolvida em Java Swing com integração ao MySQL.

O sistema possui duas etapas: criação de conta ou login e cadastro de nomes após a autenticação.

## Tecnologias utilizadas

- Java
- Java Swing
- MySQL
- JDBC
- MySQL Connector/J

## Estrutura do banco de dados

Database: `db_sistema`

Tabelas:

- `autenticacao`: armazena ID, login e senha protegida com hash SHA-256.
- `usuarios`: armazena ID e nome dos usuários cadastrados.

## Configuração

1. Inicie o servidor MySQL.
2. Execute o arquivo `banco.sql`.
3. Abra o projeto na sua IDE Java.
4. Confira o usuário e a senha do MySQL no arquivo `SistemaUnico.java`.
5. Adicione o MySQL Connector/J nas bibliotecas do projeto.
6. Execute a classe `SistemaUnico`.

## Funcionamento

1. O usuário informa login e senha.
2. Pode criar uma nova conta ou entrar em uma conta existente.
3. Após o login, o sistema abre a tela de cadastro.
4. É possível adicionar nomes e visualizar os registros salvos no MySQL.
5. O botão "Sair da conta" retorna à tela inicial.

## Arquivos do projeto

- `SistemaUnico.java`
- `banco.sql`
- `README.md`

## Autor

Erick Constante Silva

## Repositório GitHub

https://github.com/ErickConstante/cadastro-usuarios-java
