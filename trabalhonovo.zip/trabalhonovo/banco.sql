
CREATE DATABASE IF NOT EXISTS db_sistema;

USE db_sistema;

-- Tabela de autenticação
CREATE TABLE IF NOT EXISTS autenticacao (
    id INT NOT NULL AUTO_INCREMENT,
    login VARCHAR(60) NOT NULL,
    senha CHAR(64) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_autenticacao_login (login)
);

-- Tabela de usuários cadastrados
CREATE TABLE IF NOT EXISTS usuarios (
    id INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(120) NOT NULL,
    PRIMARY KEY (id)
);

-- Garante espaço para armazenar o hash SHA-256
ALTER TABLE autenticacao
MODIFY senha CHAR(64) NOT NULL;
